#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int i = get_int();
    printf("hello, %i\n", i);
}